package ECommerce.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ECommerce.DAO.CartDAO;
import ECommerce.model.CartItem;

@Service
public class CartServiceDaoImpl implements CartServiceDao {

    @Autowired
    private CartDAO cartDAO;

    @Override
    @Transactional
    public void addCartItem(CartItem cartItem) {
        cartDAO.addCartItem(cartItem);
    }

    @Override
    @Transactional
    public List<CartItem> listCartItems(String username) {
        return cartDAO.listCartItems(username);
    }

    @Override
    @Transactional
    public CartItem getCartItem(int cartItemId) {
        return cartDAO.getCartItem(cartItemId);
    }

    @Override
    @Transactional
    public void updateCartItem(CartItem cartItem) {
        cartDAO.updateCartItem(cartItem);
    }

    @Override
    @Transactional
    public void deleteCartItem(CartItem cartItem) {
        cartDAO.deleteCartItem(cartItem);
    }
}
