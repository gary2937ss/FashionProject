package ECommerce.service;

import java.util.List;

import ECommerce.model.Category;

public interface CategoryServiceDao {
    
	// Create
    boolean addCategory(Category category);
    
    // Read
    List<Category> listCategories();
    Category getCategory(int categoryId);
    
    // Update
    boolean updateCategory(Category category);
    
    // Delete
    boolean deleteCategory(Category category);
}
