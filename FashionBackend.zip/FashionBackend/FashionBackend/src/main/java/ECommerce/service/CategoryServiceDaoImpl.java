package ECommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ECommerce.DAO.CategoryDAO;
import ECommerce.model.Category;

@Service
public class CategoryServiceDaoImpl implements CategoryServiceDao {

    @Autowired
    private CategoryDAO categoryDAO;

    @Override
    @Transactional
    public boolean addCategory(Category category) {
        return categoryDAO.addCategory(category);
    }

    @Override
    @Transactional
    public List<Category> listCategories() {
        return categoryDAO.listCategories();
    }

    @Override
    @Transactional
    public Category getCategory(int categoryId) {
        return categoryDAO.getCategory(categoryId);
    }

    @Override
    @Transactional
    public boolean updateCategory(Category category) {
        return categoryDAO.updateCategory(category);
    }

    @Override
    @Transactional
    public boolean deleteCategory(Category category) {
        return categoryDAO.deleteCategory(category);
    }
}
