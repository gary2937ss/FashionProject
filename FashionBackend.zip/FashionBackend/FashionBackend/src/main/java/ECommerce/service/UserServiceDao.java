package ECommerce.service;

import ECommerce.model.UserDetail;

public interface UserServiceDao {
    // Create
    public boolean registerUser(UserDetail user);

    // Update
    public boolean updateUser(UserDetail user);

    // Read
    public UserDetail getUser(String userName);
}
