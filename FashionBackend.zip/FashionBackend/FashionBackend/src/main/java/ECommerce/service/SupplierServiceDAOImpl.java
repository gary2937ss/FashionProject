package ECommerce.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ECommerce.DAO.SupplierDAO;
import ECommerce.model.Supplier;

@Service
public class SupplierServiceDAOImpl implements SupplierServiceDAO {

    @Autowired
    private SupplierDAO supplierDAO;

    @Override
    @Transactional
    public boolean addSupplier(Supplier supplier) {
        return supplierDAO.addSupplier(supplier);
    }

    @Override
    @Transactional
    public List<Supplier> listSuppliers() {
        return supplierDAO.listSuppliers();
    }

    @Override
    @Transactional
    public Supplier getSupplier(int supplierId) {
        return supplierDAO.getSupplier(supplierId);
    }

    @Override
    @Transactional
    public boolean updateSupplier(Supplier supplier) {
        return supplierDAO.updateSupplier(supplier);
    }

    @Override
    @Transactional
    public boolean deleteSupplier(Supplier supplier) {
        return supplierDAO.deleteSupplier(supplier);
    }
}