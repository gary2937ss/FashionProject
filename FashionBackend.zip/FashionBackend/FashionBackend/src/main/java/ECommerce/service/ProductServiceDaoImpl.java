package ECommerce.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ECommerce.DAO.ProductDAO;
import ECommerce.model.Product;

@Service
public class ProductServiceDaoImpl implements ProductServiceDao {
    
    @Autowired
    private ProductDAO productDAO;

    @Override
    @Transactional
    public boolean addProduct(Product product) {
        return productDAO.addProduct(product);
    }

    @Override
    @Transactional
    public List<Product> listProducts() {
        return productDAO.listProducts();
    }

    @Override
    @Transactional
    public Product getProduct(int productId) {
        return productDAO.getProduct(productId);
    }

    @Override
    @Transactional
    public boolean updateProduct(Product product) {
        return productDAO.updateProduct(product);
    }

    @Override
    @Transactional
    public boolean deleteProduct(Product product) {
        return productDAO.deleteProduct(product);
    }
}
