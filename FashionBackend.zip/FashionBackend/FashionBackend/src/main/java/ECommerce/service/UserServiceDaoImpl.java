package ECommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ECommerce.DAO.UserDAO;
import ECommerce.model.UserDetail;

@Service
public class UserServiceDaoImpl implements UserServiceDao {

    @Autowired
    private UserDAO userDAO;

    @Override
    @Transactional
    public boolean registerUser(UserDetail user) {
        return userDAO.registerUser(user);
    }

    @Override
    @Transactional
    public boolean updateUser(UserDetail user) {
        return userDAO.updateUser(user);
    }

    @Override
    @Transactional
    public UserDetail getUser(String userName) {
        return userDAO.getUser(userName);
    }
}
