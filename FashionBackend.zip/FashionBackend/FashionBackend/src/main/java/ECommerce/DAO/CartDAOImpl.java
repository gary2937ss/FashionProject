package ECommerce.DAO;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import ECommerce.model.CartItem;

@Repository("CartDAO")
public class CartDAOImpl implements CartDAO {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void addCartItem(CartItem cartItem) {
        sessionFactory.getCurrentSession().save(cartItem);
    }

    @Override
    public List<CartItem> listCartItems(String username) {
        Query<CartItem> query = sessionFactory.getCurrentSession().createQuery("from CartItem where username = :username", CartItem.class);
        query.setParameter("username", username);
        return query.list();
    }

    @Override
    public CartItem getCartItem(int cartItemId) {
        return sessionFactory.getCurrentSession().get(CartItem.class, cartItemId);
    }

    @Override
    public void updateCartItem(CartItem cartItem) {
        sessionFactory.getCurrentSession().update(cartItem);
    }

    @Override
    public void deleteCartItem(CartItem cartItem) {
        sessionFactory.getCurrentSession().delete(cartItem);
    }
}
