package ECommerce.DAO;

import java.util.List;


import ECommerce.model.Product;

public interface ProductDAO {
	
	// Create
    boolean addProduct(Product product);
    
    // Read
    List<Product> listProducts();
    Product getProduct(int productId);
    
    // Update
    boolean updateProduct(Product product);
    
    // Delete
    boolean deleteProduct(Product product);

}
