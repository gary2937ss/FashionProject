package ECommerce.DAO;

import java.util.List;
import ECommerce.model.Supplier;

public interface SupplierDAO {
    // Create
    boolean addSupplier(Supplier supplier);
    
    // Read
    List<Supplier> listSuppliers();
    Supplier getSupplier(int supplierId);
    
    // Update
    boolean updateSupplier(Supplier supplier);
    
    // Delete
    boolean deleteSupplier(Supplier supplier);
}
