package ECommerce.DAO;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import ECommerce.model.Supplier;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public boolean addSupplier(Supplier supplier) {
        try {
            sessionFactory.getCurrentSession().save(supplier);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Supplier> listSuppliers() {
        Session session = sessionFactory.getCurrentSession();
        Query<Supplier> query = session.createQuery("from Supplier", Supplier.class);
        return query.getResultList();
    }

    @Override
    public Supplier getSupplier(int supplierId) {
        return sessionFactory.getCurrentSession().get(Supplier.class, supplierId);
    }

    @Override
    public boolean updateSupplier(Supplier supplier) {
        try {
            sessionFactory.getCurrentSession().update(supplier);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteSupplier(Supplier supplier) {
        try {
            sessionFactory.getCurrentSession().delete(supplier);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
