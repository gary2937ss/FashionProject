package ECommerce.DAO;

import java.util.List;

import ECommerce.model.Supplier;
import ECommerce.model.UserDetail;

public interface UserDAO {
	
			//Create
			public boolean registerUser(UserDetail user);
						
			//Update
			public boolean updateUser(UserDetail user);
			
			//Read
			public UserDetail getUser(String userName);


}
