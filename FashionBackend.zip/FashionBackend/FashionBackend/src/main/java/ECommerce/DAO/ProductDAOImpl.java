package ECommerce.DAO;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import ECommerce.model.Product;

@Repository("productDAO")
public class ProductDAOImpl implements ProductDAO {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public boolean addProduct(Product product) {
        try {
            sessionFactory.getCurrentSession().save(product);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Product> listProducts() {
        Session session = sessionFactory.getCurrentSession();
        Query<Product> query = session.createQuery("from Product", Product.class);
        return query.getResultList();
    }

    @Override
    public Product getProduct(int productId) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Product.class, productId);
    }

    @Override
    public boolean updateProduct(Product product) {
        try {
            sessionFactory.getCurrentSession().update(product);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteProduct(Product product) {
        try {
            sessionFactory.getCurrentSession().delete(product);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
