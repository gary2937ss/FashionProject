package ECommerce.DAO;

import java.util.List;
import ECommerce.model.CartItem;

public interface CartDAO {
    	// Create
    	void addCartItem(CartItem cartItem);
    
    	// Read
    	List<CartItem> listCartItems(String username);
    	CartItem getCartItem(int cartItemId);
    
    	// Update
    	void updateCartItem(CartItem cartItem);
    
    	// Delete
    	void deleteCartItem(CartItem cartItem);
}
