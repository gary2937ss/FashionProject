package ECommerce.config;

import java.util.Properties;
import javax.sql.DataSource;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import ECommerce.model.*;

@Configuration
@ComponentScan(basePackages = "ECommerce")
@EnableTransactionManagement
public class DBconfig {
    
    @Bean(name="dataSource")
    public DataSource getMySQLDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/ecommerce");
        dataSource.setUsername("root");
        dataSource.setPassword("1234");
        
        System.out.println("--------DataSource Object is Created------");
        
        return dataSource;
    }
    
    @Bean(name = "sessionFactory")
    public SessionFactory getSessionFactory() {
        Properties hibernateProp = new Properties();
        hibernateProp.put("hibernate.hbm2ddl.auto", "update");        
        hibernateProp.put("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect");//SQL版本
        hibernateProp.put("hibernate.show_sql", "true");
        hibernateProp.put("hibernate.format_sql", "true");
        //hibernateProp.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");

        LocalSessionFactoryBuilder localFactory = new LocalSessionFactoryBuilder(getMySQLDataSource());
        localFactory.addProperties(hibernateProp);        
        localFactory.addAnnotatedClass(Category.class); 
        localFactory.addAnnotatedClass(Product.class);
        localFactory.addAnnotatedClass(Supplier.class);
        localFactory.addAnnotatedClass(UserDetail.class);
        localFactory.addAnnotatedClass(CartItem.class);
        
        System.out.println("--------SessionFactory Object is Created------");
        
        return localFactory.buildSessionFactory();        
    }
    
    @Bean(name = "txManager")
    public HibernateTransactionManager getTransacationManager(SessionFactory sessionFactory) {
        System.out.println("--------Transaction Manager Object Created-------");
        return new HibernateTransactionManager(sessionFactory);
    }
}
