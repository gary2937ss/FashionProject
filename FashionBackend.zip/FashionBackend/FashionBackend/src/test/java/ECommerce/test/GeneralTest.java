package ECommerce.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import ECommerce.FashionBackendApplication;
import ECommerce.DAO.CategoryDAO;
import ECommerce.model.Category;
import ECommerce.service.CategoryServiceDao;
import ECommerce.config.DBconfig; // 確保這個導入

@SpringBootTest(classes = {FashionBackendApplication.class, DBconfig.class}) // 添加 DBconfig 類


public class GeneralTest {

    @Autowired
    private CategoryServiceDao categoryServiceDao;

    @BeforeAll
    public static void setup() {
        // 初始化代碼（如果需要）
    }

    @Test
    public void addCategoryTest() {
        Category category = new Category();
        category.setCategoryName("T-Shirt");
        category.setCategoryDesc("All variety of T-shirt");

        assertTrue(categoryServiceDao.addCategory(category),"Problem in adding Category");
    }
}
