package ECommerce.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import ECommerce.FashionBackendApplication;
import ECommerce.config.DBconfig;
import ECommerce.model.Product;
import ECommerce.service.ProductServiceDao;

@SpringBootTest(classes = {FashionBackendApplication.class, DBconfig.class})
public class ProductJunitTest {
    
    @Autowired
    private ProductServiceDao productServiceDao;

    @BeforeAll
    public static void setup() {
        // 在此處初始化必要的資源
    }

    @Test
    public void addProductTest() {
        Product product = new Product();
        product.setProductName("B-Shirt");
        product.setProductDesc("United Colours of Benetton");
        product.setPrice(800);
        product.setStock(45);
        product.setCategoryId(18);
        product.setSupplierId(15);

        assertTrue(productServiceDao.addProduct(product), "Problem in adding Product");
    }
}
