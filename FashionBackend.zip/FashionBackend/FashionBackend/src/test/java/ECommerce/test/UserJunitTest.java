package ECommerce.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import ECommerce.FashionBackendApplication;
import ECommerce.config.DBconfig;
import ECommerce.model.UserDetail;
import ECommerce.service.UserServiceDao;

@SpringBootTest(classes = {FashionBackendApplication.class, DBconfig.class})
public class UserJunitTest {

    @Autowired
    private UserServiceDao userServiceDao;

    @BeforeAll
    public static void setup() {
        // 在此處初始化必要的資源
    }

    @Test
    public void registerUserTest() {
        UserDetail user = new UserDetail();
        user.setUserName("abc");
        user.setPassword("123");
        user.setEnabled(true);
        user.setRole("USER");
        user.setCustomerName("John Doe");
        user.setCustomerAddr("Taipei");
        
        

        assertTrue(userServiceDao.registerUser(user), "Problem in registering User");
    }
}
