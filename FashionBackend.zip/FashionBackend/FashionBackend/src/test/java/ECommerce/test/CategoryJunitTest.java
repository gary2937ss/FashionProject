package ECommerce.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import ECommerce.FashionBackendApplication;
import ECommerce.config.DBconfig;
import ECommerce.service.CategoryServiceDao;
import ECommerce.model.Category;

@SpringBootTest(classes = {FashionBackendApplication.class, DBconfig.class})
public class CategoryJunitTest {

    @Autowired
    private CategoryServiceDao categoryServiceDao;

    @Test
    public void addCategoryTest() {
        Category category = new Category();
        category.setCategoryName("T-Shirt");
        category.setCategoryDesc("All variety of T-shirt");

        assertTrue(categoryServiceDao.addCategory(category), "Problem in adding Category");
    }
}
