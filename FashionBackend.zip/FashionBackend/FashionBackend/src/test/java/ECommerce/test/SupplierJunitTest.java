package ECommerce.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import ECommerce.FashionBackendApplication;
import ECommerce.config.DBconfig;
import ECommerce.model.Supplier;
import ECommerce.service.SupplierServiceDAO;

@SpringBootTest(classes = {FashionBackendApplication.class, DBconfig.class})
public class SupplierJunitTest {

    @Autowired
    private SupplierServiceDAO supplierServiceDAO;

    @BeforeAll
    public static void setup() {
        // 在此處初始化必要的資源
    }

    @Test
    public void addSupplierTest() {
        Supplier supplier = new Supplier();
        supplier.setSupplierId(5);
        supplier.setSupplierAddr("DOG");
        supplier.setSupplierName("CAT");

        assertTrue(supplierServiceDAO.addSupplier(supplier), "Problem in adding Supplier");
    }
}
